﻿using Verse;

namespace MenAndBeasts
{
    public class MenAndBeastsMod : Mod
    {
        public MenAndBeastsMod(ModContentPack content) : base(content)
        {
        }
    }
}